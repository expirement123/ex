#include<stdio.h>
#include"aes128.h"
int main(void){
    printf("unsigned char sbox[] = {\n");
    for (int b=0; b<256; b++){
        unsigned char temp, res;
        temp = Inverse(b);
        res = Affine(temp);
        if(b == 255){
            printf("%d\n};", res);
        }else{
            printf("%d,\n", res);
        }
    }
    return 0;
}
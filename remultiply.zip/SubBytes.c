#include"aes128.h"
extern unsigned char sbox[];

void SubBytes(unsigned char state[4*Nb]){
    for (int i=0; i<=4*Nb-1; i++){
        state[i] = sbox[state[i]];
    }
}
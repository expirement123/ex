//* ogawa *//
#include<stdio.h>
/*#include"aes128.h"*/
/*unsigned char Inverse(unsigned char b){*/
int main(){
	/*unsigned char temp;*/
	int b= 2;
	int temp = 0;
	if(b==0){
		return b;
	}else{
		temp = b;
	}
	for (int i=1; i <= 254; i++){
		/*temp = Multiply(temp, b);*/
		b = b+1;
	}
	temp = b;
	printf("%d\n", temp);
	return temp;
}



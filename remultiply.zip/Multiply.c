unsigned char Multiply(unsigned char x, unsigned char y)
{
    unsigned z = 0;
    while(y != 0){
        if(y % 2 == 1){
            z = z ^ x;
        }
        y = y >> 1;
        if(x - 0b01111111 > 0){
            x = x << 1;
            x = x ^ 0b00011011;
        }
        else{
            x = x << 1;
        }
    }
    return z;
}
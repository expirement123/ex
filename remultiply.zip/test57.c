//* ogawa *//
#include<stdio.h>
#include"aes128.h"
unsigned char Inverse(unsigned char b){
	unsigned char temp;
	if(b==0){
		return b;
	}else{
		temp = b;
	}
	char b2, b4, b8, b16, b32, b64, b128;
	b2 = Multiply(temp, b);
	b4 = Multiply(b2, b2);
	b8 = Multiply(b4, b4);
	b16 = Multiply(b8, b8);
	b32 = Multiply(b16, b16);
	b64 = Multiply(b32, b32);
	b128 = MUltiply(b64, b64);
	temp = Multiply(Multiply(Multiply(Multiply(Multiply(Multiply(Multiply(Multiply(temp, b), b2), b4), b8), b16), b32), b64), b128);
	return temp;
}



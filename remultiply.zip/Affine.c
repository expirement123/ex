unsigned char Affine(unsigned char b)
{
    unsigned char b0, b1, b2, b3, b4, ans;
    //2進数:b7 b6 b5 b4  b3 b2 b1 b0の並び
    unsigned char c = 0b01100011;
    b0 = b;
    b1 = (b >> 4) ^ (b << 4);
    b2 = (b >> 5) ^ (b << 3);
    b3 = (b >> 6) ^ (b << 2);
    b4 = (b >> 7) ^ (b << 1);
    ans = b0 ^ b1 ^ b2 ^ b3 ^ b4 ^ c;
    return ans;
}
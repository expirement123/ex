#include<stdio.h>
unsigned char Multiply(unsigned char x, unsigned char y){
    unsigned char z = 0;
    do{
        if (y%2==1){
        z = z ^ x;
        }
        y >>= 1;
        if ((x>>7) == 1){
            x <<= 1;
            x = x ^ 27;
        }else{
            x <<= 1;
        }
    }while (y!=0); 
    return z;
}


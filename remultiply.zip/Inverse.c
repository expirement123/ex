//* ogawa *//
#include"aes128.h"
unsigned char Inverse(unsigned char b){
	unsigned char temp;
	if(b==0){
		return b;
	}
	temp = b;
	for (int i=1; i < 254; i++){
		temp = Multiply(temp, b);
	}
	return temp;
}



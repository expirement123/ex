#include"aes128.h"
extern unsigned char mbox02[];
extern unsigned char mbox03[];

void MixColumns(unsigned char state[16]){
    unsigned char res[16];
    for(int i=0; i<13; i+=4){
        res[i] = mbox02[state[i]] ^ mbox03[state[i+1]] ^ state[i+2] ^ state[i+3];
        res[i+1] = state[i] ^ mbox02[state[i+1]] ^ mbox03[state[i+2]] ^ state[i+3];
        res[i+2] = state[i] ^ state[i+1] ^ mbox02[state[i+2]] ^ mbox03[state[i+3]];
        res[i+3] = mbox03[state[i]] ^ state[i+1] ^ state[i+2] ^ mbox02[state[i+3]];
    }
    for(int i=0; i<16; i++){
        state[i] = res[i];
    }
}
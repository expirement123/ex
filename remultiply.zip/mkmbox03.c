#include<stdio.h>
#include "aes128.h"
int main(void)
{
    unsigned char res;
    int b = 0;
    printf("unsigned char mbox03[256] = { \n");
    for(b = 0; b < 256; b++){
        res = Multiply(b, 0x03);
        printf(" 0x%x", res);
        if(b != 255){
            printf(",");
        }
        if(b % 16 == 15){
            printf("\n");
        }
    }
    printf("}; \n");
}